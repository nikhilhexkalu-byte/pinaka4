# K05 — Sampati: The Hundred-Yojana Sight

*The vanaras reach the southern shore and can go no further — before them lies the ocean, and
somewhere beyond it, the island fortress where Sita is held. There they find Sampati, the aged
king of vultures, Jatayu's elder brother, his wings long burnt away but his sight undimmed: he
alone can see a hundred yojanas across the water. Sampati looked toward Lanka from many perches
along the cliffs and recorded what his eyes caught of Trikuta's three peaks, where the fortress
stands. But the sea's air bends every far sight-line, his old eyes no longer sit true in their
sockets, and for several of the perches only half of what he saw was ever set down. From these
refracted, mis-aimed, half-missing sightings, the exact place of Lanka must still be fixed.*

## What you are given

One binary artifact recovered from Sampati's record of the sighting (a custom, undocumented
little-endian format — no schema is published):

| File | What it is |
|---|---|
| `sightings.sampati` | Sampati's optical observation log: a header with the shared **nominal** lens constants (focal length and principal point); a table of **perches** (each with its known 3-D position and its known world-to-eye orientation); and a table of **sightings** — for each perch, its view of each of Trikuta's three peaks as an image coordinate `(u, v)`. Every record carries a CRC32. Some sightings are **incomplete**: only the `u` coordinate or only the `v` coordinate was recorded. |

Across every sighting, two things corrupt the raw image coordinates in the same way for all
perches:

- **Atmospheric distortion** — the ocean air refracts each sight-line *radially*, by an amount
  that grows with the square (and fourth power) of the distance of the point from the image
  centre. Two global coefficients `(k1, k2)` describe it; they are **not** given to you.
- **Calibration error** — Sampati's eye no longer sits at the nominal principal point; every
  sighting is shifted by the same unknown offset `(dcx, dcy)` in pixels. Also **not** given.

The three peak positions, `(k1, k2)`, and `(dcx, dcy)` are all unknown. Nothing in the file is
random filler — every byte is one coherent sighting. The flag is **not** present in the file.

## The optical model

For a perch with position `C` and world-to-eye orientation `R`, a peak at world position `L`
appears at image coordinate:

```
Pc = R @ (L - C)                         # eye-frame coordinates (Xc, Yc, Zc); Zc = view axis
x  = Xc / Zc ,   y = Yc / Zc             # ideal pin-hole projection
r2 = x*x + y*y
D  = 1 + k1*r2 + k2*r2*r2                # radial atmospheric distortion (global k1, k2)
u  = f * (D * x) + (cx + dcx)            # (dcx, dcy): global principal-point calibration error
v  = f * (D * y) + (cy + dcy)
```

`f`, `cx`, `cy` are the nominal lens constants from the header. This map is **nonlinear** in the
unknowns (the division by `Zc`, the radial powers, and the product of the distortion with the
geometry), so there is no linear triangulation that recovers the answer — a genuine nonlinear
least-squares / bundle-adjustment solve is required.

## Your goal

Reconstruct the **single landmark** consistent with all of Sampati's records: the 3-D positions
of Trikuta's three peaks, together with the atmospheric coefficients and the calibration offset
that the whole set of sightings uniquely determines. Then **complete** the sightings that were
left half-recorded by predicting their missing coordinate from your reconstruction. Present it
all to Sampati's seal (the validator) for your instance. The seal checks your reconstruction
against the true sighting server-side and, only on an exact match, returns the flag. The
landmark is uniquely determined; guessing will not find it.

## Submission

`POST /lanka/sighting` with a JSON body:

```json
{
  "peaks": [[X,Y,Z], [X,Y,Z], [X,Y,Z]],
  "distortion": [k1_micro, k2_micro],
  "calibration": [dcx_milli, dcy_milli],
  "completed": [[station, peak, axis, value_milli], ...],
  "reconstruction_digest": "<sha256 hex>",
  "sight_range": <integer>
}
```

- **peaks** — the three reconstructed peak positions, each as integer position units, in
  ascending peak-id order (peak id = the `point_id` used in the sighting records).
- **distortion** — the recovered atmospheric coefficients, as integers `round(k * 1e6)`
  (micro-units): `[round(k1*1e6), round(k2*1e6)]`.
- **calibration** — the recovered principal-point offset, as integers `round(d * 1e3)`
  (milli-pixels): `[round(dcx*1e3), round(dcy*1e3)]`.
- **completed** — one entry per *missing* coordinate in the log: `[station_id, peak_id, axis,
  value_milli]`, where `axis` is `0` for a missing `u` and `1` for a missing `v`, and
  `value_milli = round(predicted_coordinate * 1e3)`. Order does not matter.
- **reconstruction_digest** — a fingerprint of the whole reconstruction: build the string
  `"P0:X,Y,Z"` for each peak id, then `"K:k1_micro,k2_micro"`, then `"C:dcx_milli,dcy_milli"`,
  then `"M:station,peak,axis,value_milli"` for each completed coordinate **sorted ascending by
  `[station, peak, axis, value]`**; join all parts with `;` and take the SHA-256 hex.
- **sight_range** — the integer distance from the shore origin `(0,0,0)` to the centroid of the
  three reconstructed peaks (`round(|centroid|)`), Sampati's hundred-yojana sight-line.

All fields must be exactly right together. A reconstruction that ignores the atmosphere, or the
calibration error, or that mishandles the incomplete sightings, will land on a different
landmark and be refused.
