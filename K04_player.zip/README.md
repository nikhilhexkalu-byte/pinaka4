# K04 — The Four Directions: Search Without Borders

*Sugriva, king of the vanaras, keeps his oath to Rama. He musters his hosts and sends four
search parties to the four directions — North, East, West, and South — to find where Ravana
has hidden Sita. Each party maps the region it was given: every clearing, every trail between
them, and the measured worth of walking each trail, written in the army's own dishā-map
ledgers. The crossings where one party's region meets the next were kept in a shared border
ledger. But the hosts marched in haste through monsoon and curse, and the border ledger came
back torn: many crossing-measurements garbled, some lost entirely, whole stretches overwritten.*

*No single party can see past its own borders. Each carries only a field-engine — a dik-yantra
— that weighs a passage through its own region and nothing more. To trace the one true trail
that leads to Sita, the four maps must be stitched back into one: the lost crossings
reconstructed, the parties' own measure of a passage's worth understood, and the single safe
route followed from the muster point in the North to where Sita is held in the South.*

## What you are given

| File | What it is |
|---|---|
| `region_uttara.map`    | The **North** party's region map — clearings and trails, in the army's dishā-map format (custom, undocumented). |
| `region_purva.map`     | The **East** party's region map. |
| `region_paschima.map`  | The **West** party's region map. |
| `region_dakshina.map`  | The **South** party's region map — Sita is held somewhere within it. |
| `border.ledger`        | The shared ledger of **crossings** between adjacent regions. **Damaged**: records torn, some crossings lost, a stretch overwritten. |
| `dik_engine.py`        | A search party's **field-engine**. Load one region map and it will weigh the party's chosen passage between two clearings *within that one region*, returning the passage and its **toll** (a single number). It cannot cross borders, and it does not tell you how the toll is composed. |

The four region maps are intact. Only the border ledger is damaged. Nothing in any file is
random filler — the whole corpus is one consistent record of one search. **The flag is not in
any file.**

## Your goal

Recover the **single consistent route** — the one trail the four parties' records, read and
stitched correctly, uniquely determine — from the muster point (`source`, a clearing of the
North region) to Sita's prison (`target`, a clearing of the South region). The route crosses
all four regions in turn. To find it you must:

1. **Reverse** the dishā-map and border-ledger binary formats.
2. **Learn the parties' measure** of a passage's worth — the rule the field-engine uses to
   weigh one passage against another. It is *not* a plain shortest path, and it is *not* the
   first number in a trail record. Probe the engine; the toll will teach you.
3. **Reconstruct the lost crossings** between regions from what the ledger and the maps still
   agree on.
4. **Stitch** the four regions into one and trace the single best route under the parties' own
   measure.

Present it, with the key facts you recovered, to Sugriva's seal (the validator) for your
instance. The seal checks your answer server-side against the parties' true record and, only on
an exact match, returns the flag. There is exactly one route that passes; guessing will not
find it.

## Submission

`POST /vana/dishamukha` with a JSON body:

```json
{
  "route": [source_gid, ..., target_gid],
  "route_peril": <integer>,
  "route_length": <integer>,
  "route_score": <integer>,
  "metric": { "peril_field": "<field>", "length_field": "<field>", "peril_weight": <integer> },
  "committed_edge_count": <integer>,
  "border_edge_count": <integer>,
  "border_digest": "<sha256 hex>",
  "committed_graph_digest": "<sha256 hex>"
}
```

- **route** — the ordered list of clearing ids (global ids: `region_id * 10000000 + local_id`)
  from `source` to `target`.
- **route_peril**, **route_length** — the two components of the route's total worth.
- **route_score** — the route's total worth as the single number the parties compare by.
- **metric** — the measure you inferred: which trail field is *peril*, which is *length*, and
  the weight that makes peril dominate length.
- **committed_edge_count** — how many trails (intra-region + reconstructed crossings) are in the
  stitched graph you recovered.
- **border_edge_count** — how many cross-region crossings you reconstructed.
- **border_digest** — a fingerprint of the reconstructed crossings: for every crossing, the
  string `src>dst:peril:length`, sorted ascending as text, joined with `;`, SHA-256 (hex).
- **committed_graph_digest** — the same fingerprint taken over *every* trail in the stitched
  graph (intra-region trails and reconstructed crossings together).

All fields must be exactly right together. A route that rests on a crossing the ledger never
truly recorded, or on the wrong measure of worth, will be refused.
