#!/usr/bin/env python3
"""Field engine for dishā-map traversal."""
import struct, zlib

_M = b"PNKDISHA"
_K = 0x3B9ACA00


def _c(b):
    return zlib.crc32(b) & 0xffffffff


class Yantra:
    def __init__(self, path):
        with open(path, "rb") as f:
            d = f.read()
        h = struct.calcsize("<8sHHIIIIII")
        (m, _v, self.rid, nc, ec, _pc, ncrc, ecrc, hc) = struct.unpack("<8sHHIIIIII", d[:h])
        if m != _M or hc != _c(d[:h - 4]):
            raise ValueError("not a dishā-map (or torn header)")
        p = h
        nb = d[p:p + nc * 6]
        if _c(nb) != ncrc:
            raise ValueError("torn node block")
        p += nc * 6
        eb = d[p:p + ec * 20]
        if _c(eb) != ecrc:
            raise ValueError("torn trail block")

        self._depth = [0] * nc
        for i in range(nc):
            dp, _pk = struct.unpack("<Hi", nb[i * 6:(i + 1) * 6])
            self._depth[i] = dp

        self._adj = {}
        for j in range(ec):
            s, t, f0, f1, f2 = struct.unpack("<IIIII", eb[j * 20:(j + 1) * 20])
            self._adj.setdefault(s, []).append((t, self._toll(f0, f1, f2)))
        self.node_count = nc
        self.trail_count = ec

    def _toll(self, f0, f1, f2):
        a, b, c = f0, f1, f2
        return (b * _K) + c

    def weigh(self, src, dst):
        order = sorted(range(self.node_count), key=lambda n: (self._depth[n], n))
        best = {src: 0}
        prev = {src: None}
        for u in order:
            if u not in best:
                continue
            bu = best[u]
            for (v, w) in self._adj.get(u, []):
                nb = bu + w
                if v not in best or nb < best[v]:
                    best[v] = nb
                    prev[v] = u
        if dst not in best:
            return None
        path = [dst]
        while path[-1] is not None and path[-1] != src:
            path.append(prev[path[-1]])
        path.reverse()
        return {"path": path, "toll": best[dst]}


if __name__ == "__main__":
    import sys
    y = Yantra(sys.argv[1])
    print(f"loaded region {y.rid}: {y.node_count} clearings, {y.trail_count} trails")
    if len(sys.argv) >= 4:
        print(y.weigh(int(sys.argv[2]), int(sys.argv[3])))
