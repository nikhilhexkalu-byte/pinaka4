# VANARA-1 — Instruction Set Reference

*The Kishkindha microarchitecture. A simulated CPU. This reference covers the guest-visible
instruction encoding. The machine's internal structure — its execution model, resource
management, and protection boundaries — you must learn by experiment.*

## Machine model

- **Registers:** `R0`–`R7`, each a 64-bit unsigned integer. All start at 0.
- **Guest RAM:** a flat byte array the guest can `LD`/`ST`. Addresses outside guest RAM
  return `0`.
- **Kernel gadget:** invoked by `GINV rX`. The gadget accepts an index and performs an
  internal operation. Guests observe no direct architectural result from the gadget.
- **System calls:** `FLUSH` and `TIME` interact with internal machine state. `FLUSH`
  resets an unspecified subsystem. `TIME rX, rY` writes a binary value to `rX` depending
  on `rY` and prior machine activity.

## Instruction encoding

Every instruction is exactly **4 bytes**: `[opcode, x, y, z]`. Programs are a concatenation of
such instructions, submitted as ASCII hex to `POST /vanara/run`.

| Op | Mnemonic | Operands | Effect |
|----|----------|----------|--------|
| 00 | `HALT` | — | stop |
| 01 | `MOVI rX, imm16` | x=reg, (y,z)=imm16 lo/hi | `rX = imm16` |
| 02 | `MOV rX, rY` | | `rX = rY` |
| 03 | `ADD rX, rY, rZ` | | `rX = rY + rZ` |
| 04 | `SUB rX, rY, rZ` | | `rX = rY - rZ` |
| 05 | `MUL rX, rY, rZ` | | `rX = rY * rZ` |
| 06 | `ADDI rX, rY, imm8` | z=imm8 | `rX = rY + imm8` |
| 07 | `SHL rX, rY, imm8` | z=imm8 | `rX = rY << imm8` |
| 08 | `LD rX, [rY]` | | `rX = guest_ram[rY]` (0 outside guest RAM) |
| 09 | `ST [rX], rY` | | `guest_ram[rX] = rY & 0xFF` |
| 0A | `FLUSH` | — | system call: internal reset |
| 0B | `GINV rX` | | invoke the kernel gadget with index `rX` |
| 0C | `TIME rX, rY` | | system call: `rX` set based on `rY` and machine state |
| 0D | `OUT rX` | | append `rX & 0xFF` to the program's output |
| 0E | `JMP target` | (y,z)=imm16 | jump to instruction index |
| 0F | `JZ rX, target` | | jump if `rX == 0` |
| 10 | `JNZ rX, target` | | jump if `rX != 0` |
| 11 | `CMPLT rX, rY, rZ` | | `rX = 1` if `rY < rZ` else `0` |
| 12 | `SUBI rX, rY, imm8` | z=imm8 | `rX = rY - imm8` |

A jump `target` is an **instruction index** (0-based). The included assembler
(`vanara_asm.py`) resolves labels for you.

## Service

- `GET /vanara/doc` — this reference, served by the live instance.
- `POST /vanara/run` — body `{"program": "<hex bytecode>"}`; returns
  `{"output": "<hex of the OUT bytes>"}`. Your program runs on the CPU that holds the secret.
- `POST /vanara/claim` — body `{"secret": "<recovered secret>"}` (raw string, hex string, or
  list of byte values). Returns the flag only when it exactly matches the protected secret.

## What you are not told

The internal architecture parameters, the protection model, the gadget's behaviour, and the
meaning of the system calls. Every one of these is observable by experiment against
`/vanara/run`. Study the machine, understand its boundaries, and make it tell you what it
is forbidden to say.
