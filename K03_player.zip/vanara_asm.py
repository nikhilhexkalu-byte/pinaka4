#!/usr/bin/env python3
"""VANARA-1 assembler — turn mnemonics into 4-byte instruction bytecode for POST /vanara/run."""
from __future__ import annotations

OPS = {
    "HALT": 0x00, "MOVI": 0x01, "MOV": 0x02, "ADD": 0x03, "SUB": 0x04,
    "MUL": 0x05, "ADDI": 0x06, "SHL": 0x07, "LD": 0x08, "ST": 0x09,
    "FLUSH": 0x0A, "GINV": 0x0B, "TIME": 0x0C, "OUT": 0x0D, "JMP": 0x0E,
    "JZ": 0x0F, "JNZ": 0x10, "CMPLT": 0x11, "SUBI": 0x12,
}
SHAPES = {
    "HALT": [], "MOVI": ["r", "i16"], "MOV": ["r", "r"], "ADD": ["r", "r", "r"],
    "SUB": ["r", "r", "r"], "MUL": ["r", "r", "r"], "ADDI": ["r", "r", "i8"],
    "SHL": ["r", "r", "i8"], "LD": ["r", "r"], "ST": ["r", "r"], "FLUSH": [],
    "GINV": ["r"], "TIME": ["r", "r"], "OUT": ["r"], "JMP": ["L"], "JZ": ["r", "L"],
    "JNZ": ["r", "L"], "CMPLT": ["r", "r", "r"], "SUBI": ["r", "r", "i8"],
}

def _reg(tok):
    t = tok.strip().rstrip(",")
    if not (t[:1] in "rR" and t[1:].isdigit() and 0 <= int(t[1:]) <= 7):
        raise ValueError(f"bad register operand {tok!r}")
    return int(t[1:])

def _imm(tok):
    t = tok.strip().rstrip(",")
    return int(t, 16) if t.lower().startswith("0x") else int(t)

def assemble(source: str) -> bytes:
    raw = []
    for line in source.splitlines():
        line = line.split(";", 1)[0].strip()
        if not line: continue
        if line.endswith(":"):
            raw.append(("label", line[:-1].strip()))
            continue
        parts = line.replace(",", " ").split()
        raw.append(("insn", parts[0].upper(), parts[1:]))
    labels, idx = {}, 0
    for item in raw:
        if item[0] == "label": labels[item[1]] = idx
        else: idx += 1
    out = bytearray()
    for item in raw:
        if item[0] == "label": continue
        _, mnem, args = item
        if mnem not in OPS: raise ValueError(f"unknown mnemonic {mnem!r}")
        if len(args) != len(SHAPES[mnem]):
            raise ValueError(f"{mnem} expects {len(SHAPES[mnem])} operands, got {len(args)}")
        op = OPS[mnem]; x = y = z = 0
        if mnem == "MOVI":
            x = _reg(args[0]); imm = _imm(args[1]) & 0xFFFF; y = imm & 0xFF; z = (imm >> 8) & 0xFF
        elif mnem == "JMP":
            tgt = labels.get(args[0], None); tgt = tgt if tgt is not None else _imm(args[0])
            y = tgt & 0xFF; z = (tgt >> 8) & 0xFF
        elif mnem in ("JZ", "JNZ"):
            x = _reg(args[0]); tgt = labels.get(args[1], None); tgt = tgt if tgt is not None else _imm(args[1])
            y = tgt & 0xFF; z = (tgt >> 8) & 0xFF
        elif mnem in ("ADDI", "SUBI", "SHL"):
            x = _reg(args[0]); y = _reg(args[1]); z = _imm(args[2]) & 0xFF
        elif mnem in ("MOV", "LD", "ST", "TIME"):
            x = _reg(args[0]); y = _reg(args[1])
        elif mnem in ("ADD", "SUB", "MUL", "CMPLT"):
            x = _reg(args[0]); y = _reg(args[1]); z = _reg(args[2])
        elif mnem in ("GINV", "OUT"):
            x = _reg(args[0])
        out += bytes((op, x & 0xFF, y & 0xFF, z & 0xFF))
    return bytes(out)

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        with open(sys.argv[1]) as f: src = f.read()
    else:
        src = "MOVI R0, 0x41\nOUT R0\nHALT"
    print(assemble(src).hex())
