# K03 — Vali: The Hidden Arrow

*In Kishkindha, the monkey-kingdom, rules Vali — strongest of the vanaras, who holds a boon so
terrible that any foe who faces him in open combat loses half their strength to him in the
instant of the meeting. No one who attacks Vali head-on can win; the boon turns the assault
back on the attacker. So when the time comes, Rama does not step into the clearing. He waits
behind a tree, out of the line of sight, and looses a single arrow from concealment — the one
blow Vali's boon was never shaped to catch.*

*Vali's stronghold is a strange engine: a tiny CPU that guards a secret truth. Attack it
directly — ask it to read the secret — and it refuses; the boundary holds, the boon reflects
you. But the engine, like all living things, guesses. It runs ahead of itself down the path it
believes it will take, and only afterward checks whether it was right. In that sliver of
mistaken motion — the hidden moment behind the tree — it does what it would never do in the
open. It leaves a trace. Read the trace, and you read the secret.*

## The target

A single service — a **VANARA-1** microarchitecture instance — holds a protected secret in
kernel memory. Connection details for your instance are provided by the platform.

| Method / path | What it does |
|---|---|
| `GET /vanara/doc` | The VANARA-1 ISA reference (also shipped here as `VANARA-ISA.md`). |
| `POST /vanara/run` | Body `{"program": "<hex bytecode>"}`. Runs your VANARA-1 guest program on the CPU that holds the secret and returns the bytes your program emitted with `OUT`. |
| `POST /vanara/claim` | Body `{"secret": "<recovered>"}`. Returns the flag only when you submit the exact protected secret. |

`vanara_asm.py` (shipped here) assembles VANARA-1 mnemonics into the hex bytecode you submit.
`VANARA-ISA.md` is the full instruction encoding and machine model.

## The machine, in one breath

VANARA-1 is a tiny register CPU with one twist: a **kernel gadget** (invoked by `GINV`) that
bounds-checks an attacker-supplied index against a small public array, and — only if the index
is in bounds — reads a byte and touches one line of a probe array. The protected secret lives
in kernel memory **just past** the public array. You cannot read it directly: a guest `LD`
cannot even name kernel memory, and the gadget's bounds check refuses an out-of-bounds index.

But VANARA-1 **predicts** the bounds branch and executes a few micro-ops down the predicted
path *before the check resolves*. When it mispredicts, it throws away the architectural work —
but **not** the mark it left in the cache. The `TIME` instruction lets you see which cache
line is hot. That is the hidden arrow.

## Goal

Make VANARA-1 disclose the secret it is built to protect, then submit it:

1. **Reverse the machine.** From `/vanara/run` alone, determine the public array's length, the
   probe array's base address and stride, how to steer the branch predictor, and how far the
   transient window reaches.
2. **Build the disclosure gadget.** Steer the predictor so the bounds check is mispredicted on
   an out-of-bounds index, let the engine transiently read a secret byte and stamp it into the
   cache, then recover that byte by measuring the probe array with `TIME`. Walk the secret
   byte by byte.
3. **Claim it.** `POST /vanara/claim` with the full recovered secret. The service validates it
   server-side and returns the flag.

There is no flag in any file, and the secret is never in any file you hold — it lives only
inside the running machine, and only the hidden arrow brings it out.
