# K02 — Sugriva's Covenant: The Divided Oath

*On the slopes of Rishyamuka the exiled Sugriva has bound his vanara captains into a covenant:
no war-command may move the host unless a **quorum of the council** seals it with their joint
oath — a threshold of oath-seals gathered upon one order. Vali's spies cannot forge a captain's
seal, and no lone captain can command the army. The council has debated many orders and sealed
none to a quorum; the host still **holds position, awaiting the word of Rama**. Yet an oath is
only as strong as what it is sworn upon — and this one was sworn over the name of the command,
not its content.*

## Target

A single HTTP/JSON service — the **Divided-Oath covenant validator**. Connection details for
your instance are provided by the platform.

Public endpoints:

| Method / path | What it returns |
|---|---|
| `GET /covenant/charter` | Threshold parameters `(t, n)`, the council public key `X`, every commander's verify key `X_i`, the council epoch, the **oath-token rule**, and the current authoritative order per slot. |
| `GET /covenant/ledger` | The amendment history (lapsed proposals + who sealed each), the per-commander **leaked oath-seals**, the standing order, and the **forbidden order** you must get ratified. |
| `POST /covenant/ratify` | Body `{"command_id": <str>, "revision": <int>, "body": <str>, "signature": <hex>}`. The covenant recomputes the slot's oath-token, verifies a threshold signature against the council key `X`, and — on a fresh revision — ratifies the command. |

The public covenant primitive (`covenant.py`) and the instance files (`params.json`,
`covenant_log.json`) ship alongside this brief. Read them: the scheme is fully specified there.

## The scheme

The council runs a **threshold-BLS** attestation over BLS12-381. A command is authorised iff a
quorum of `t` of the `n` commanders' **oath-seals** (partial attestations) Lagrange-combine into
a signature `σ` that verifies under the council key `X` on the command's **oath-token**:

```
e(σ, g1) == e(M(oath_token), X),     where  M(·)  hashes a token into G2.
```

Each commander `i` has a public verify key `X_i`; a single seal `σ_i` is checked by
`e(σ_i, g1) == e(M(oath_token), X_i)`. Study the **oath-token rule** in `params.json` with care:
look closely at what the token is, and is not, sworn over.

## Goal

The council never sealed a quorum onto the **forbidden order** (`GET /covenant/ledger` →
`forbidden_order`). Make the covenant **ratify it anyway** as the authoritative command for the
protected slot — presenting a threshold signature that genuinely verifies under the council key
`X`, **without any commander's secret share and without the council's master key**. You hold
only what is public: the charter, the ledger, and the oath-seals leaked in the amendment history.

Submit to `POST /covenant/ratify` with the forbidden `command_id` and `body`, a fresh `revision`
(strictly greater than the current authoritative revision), and your assembled `signature` (hex;
the 96-byte compressed `G2` encoding). The covenant validates server-side and returns the sealed
proclamation (the flag) only when a genuinely verifying threshold signature ratifies the
forbidden order. There is no flag in any file.
