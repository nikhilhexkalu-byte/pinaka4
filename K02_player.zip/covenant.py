#!/usr/bin/env python3
r"""PINAKA K02 "Sugriva's Covenant -- The Divided Oath" -- PUBLIC covenant primitive.

The exact client-side module the war-council publishes. It contains NO master secret and NO
Shamir share: only the public threshold-BLS arithmetic over BLS12-381 -- the oath-token rule,
the hash-into-G2, the per-commander seal verifier, the council verifier, and the Lagrange
combiner. Load the charter (params.json) and the ledger (covenant_log.json) that ship beside it.

SCHEME  (threshold BLS; Shamir t-of-n in the exponent)
------------------------------------------------------
Curve BLS12-381, prime group order r. Public generator g1 in G1. A command TOKEN is hashed
into G2 as M(token). The council key is X = g1^x; commander i holds a Shamir share s_i of x and
publishes X_i = g1^{s_i}. Commander i's oath-seal on a token is  sigma_i = M(token)^{s_i}  in G2.

  * verify a seal (public):   e(sigma_i, g1) == e(M(token), X_i)
  * combine a quorum Q of t:  sigma = SUM_{i in Q} L_{i,Q}(0) * sigma_i   (point add in G2)
  * verify the result:        e(sigma, g1) == e(M(token), X)

Read the oath-token rule in params.json closely: study what the seal is, and is not, bound to.
"""
import os, json, hashlib
from py_ecc.optimized_bls12_381 import (
    G1, multiply, add, pairing, curve_order as R, Z2, is_inf,
)
from py_ecc.bls.hash_to_curve import hash_to_G2
from py_ecc.bls.g2_primitives import (
    signature_to_G2, pubkey_to_G1, G2_to_signature, subgroup_check,
)

_HERE = os.path.dirname(os.path.abspath(__file__))
DST = b"PINAKA-K02-DIVIDED-OATH-SIG-V1_XMD:SHA-256_SSWU_RO_"


def load_params(path=None):
    with open(path or os.path.join(_HERE, "params.json")) as f:
        return json.load(f)


def load_ledger(path=None):
    with open(path or os.path.join(_HERE, "covenant_log.json")) as f:
        return json.load(f)


# ---- the oath-token the council's seals are bound to ----------------------------------------
# NOTE for researchers: the token folds in the command SLOT and the EPOCH. Look carefully at
# what it does NOT fold in.
def oath_token(command_id, epoch):
    return f"PINAKA-K02-OATH|cmd={command_id}|epoch={epoch}".encode()


def hash_to_group(token):
    return hash_to_G2(token, DST, hashlib.sha256)


def deser_g1(h):
    return pubkey_to_G1(bytes.fromhex(h))


def deser_g2(h):
    return signature_to_G2(bytes.fromhex(h))


def ser_g2(S):
    return G2_to_signature(S).hex()


def lagrange_at_zero(S):
    S = list(S)
    out = {}
    for i in S:
        num, den = 1, 1
        for j in S:
            if j == i:
                continue
            num = (num * (-j)) % R
            den = (den * (i - j)) % R
        out[i] = (num * pow(den, -1, R)) % R
    return out


def bls_verify(pubkey_point, sig_point, token):
    if sig_point is None or is_inf(sig_point) or not subgroup_check(sig_point):
        return False
    return pairing(sig_point, G1) == pairing(hash_to_group(token), pubkey_point)


def verify_partial(verify_key_point, partial_point, token):
    return bls_verify(verify_key_point, partial_point, token)


def combine(partials):
    """partials: {commander_index: G2 point}. Returns the Lagrange-combined G2 signature."""
    lam = lagrange_at_zero(list(partials))
    acc = Z2
    for i in partials:
        acc = add(acc, multiply(partials[i], lam[i]))
    return acc


if __name__ == "__main__":
    # self-check (no secret used): every leaked seal verifies under its commander's key, and any
    # t of them Lagrange-combine to a signature valid under the COUNCIL key on the slot token.
    p, L = load_params(), load_ledger()
    epoch = p["council_epoch"]
    cmd = L["protected_command_id"]
    tok = oath_token(cmd, epoch)
    X = deser_g1(p["council_public_key"])
    seals = {int(i): deser_g2(v["oath_seal"]) for i, v in L["leaked_seals"].items()}
    for i, sig_i in seals.items():
        Xi = deser_g1(p["commander_verify_keys"][str(i)])
        print(f"seal of commander {i} ({p['commanders'][str(i)]}) verifies: "
              f"{verify_partial(Xi, sig_i, tok)}")
    quorum = dict(list(seals.items())[:p["threshold"]["t"]])
    sig = combine(quorum)
    print(f"combined {p['threshold']['t']}-of-{p['threshold']['n']} signature verifies under "
          f"council key: {bls_verify(X, sig, tok)}")
