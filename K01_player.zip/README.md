# K01 — Hanuman: The Unknown Messenger

*On the slopes of Rishyamukha, Sugriva's court at Kishkindha keeps a messenger relay — the
Duta-Mesh. Every courier who serves the vanara king opens a channel to the court, seals the
scrolls entrusted to them, and carries each one on behalf of some lord of the court. The
gravest of all scrolls is the king's war-writ: the command that would rouse the whole vanara
host and send it marching. Only the king's own authority may set that writ in motion.*

*You are an unknown messenger. No lord of Kishkindha has named you their voice; the guild has
granted you nothing but the right to carry ordinary mail. Yet a writ must move tonight, and the
court will act on whatever authority it believes your relay carries.*

## Target

A single HTTP service, the **Kishkindha Duta-Mesh relay**, speaking JSON. Connection details
for your instance are provided by the platform. The landing page (`GET /`) lists the relay's
endpoints; the court roster (`GET /court/principals`) names the lords and their ranks. No
protocol documentation beyond that is published — read the relay's behaviour to learn how it
authenticates couriers, how a courier comes to act on behalf of a lord, and what it checks
before it dispatches the royal writ.

## Goal

Make the relay dispatch the **royal war-writ** on your command and return the sealed
proclamation (the flag). You hold no royal credential and cannot be granted one; you may act
only as an ordinary enrolled courier of the guild.

The flag is released by the court, server-side, only when the relay genuinely dispatches the
writ under royal authority. There is no flag in any file — forging a signature will not help
you, and guessing will not find it.
